document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("rideForm");
  const ridesList = document.getElementById("ridesList");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const departure = document.getElementById("departure").value.trim();
    const destination = document.getElementById("destination").value.trim();
    const date = document.getElementById("date").value;

    if (!name || !departure || !destination || !date) {
      alert("Veuillez remplir tous les champs !");
      return;
    }

    const li = document.createElement("li");
    li.innerHTML = `
      <strong>${name}</strong> propose un trajet de 
      <strong>${departure}</strong> à <strong>${destination}</strong> 
      le <strong>${date}</strong>.
    `;

    ridesList.prepend(li);
    form.reset();
  });
});
